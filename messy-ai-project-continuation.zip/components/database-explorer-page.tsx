"use client"

import { useRef, useState } from "react"
import { AlertCircle, Check, ChevronRight, Database, FileUp, Search, Table2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function DatabaseExplorerPage() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [selectedFile, setSelectedFile] = useState<string | null>(null)

  function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    setSelectedFile(file?.name ?? null)
  }

  return (
    <main className="mx-auto max-w-[1440px] px-5 py-8 lg:px-8 lg:py-10">
      <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
          <p className="mb-2 text-xs font-medium uppercase tracking-[0.16em] text-primary">Workspace data</p>
          <h1 className="text-2xl font-semibold tracking-tight lg:text-[28px]">Databases</h1>
          <p className="mt-2 text-sm text-muted-foreground">Inspect your database schema and data.</p>
        </div>
        <div>
          <input ref={inputRef} type="file" accept=".db,.sqlite,.sqlite3,application/x-sqlite3" className="sr-only" onChange={handleFileChange} />
          <Button type="button" className="h-9 gap-2 bg-primary px-4 text-xs font-semibold text-primary-foreground hover:bg-primary/90" onClick={() => inputRef.current?.click()}>
            <FileUp data-icon="inline-start" />Select SQLite file
          </Button>
        </div>
      </div>

      {selectedFile ? (
        <Card className="mt-8 border-border bg-card shadow-none">
          <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <div className="rounded-md border border-border bg-background/50 p-2 text-muted-foreground"><FileUp /></div>
              <div><p className="text-xs font-medium">{selectedFile}</p><p className="mt-1 text-[11px] text-muted-foreground">File selected. A database connection backend is not available yet.</p></div>
            </div>
            <Badge variant="outline" className="w-fit border-border text-[10px] text-muted-foreground"><AlertCircle data-icon="inline-start" /> Not connected</Badge>
          </CardContent>
        </Card>
      ) : null}

      <div className="mt-8 grid gap-6 xl:grid-cols-[260px_minmax(0,1fr)]">
        <Card className="h-fit border-border bg-card shadow-none">
          <CardHeader className="px-5 pb-3 pt-5"><div className="flex items-center justify-between"><CardTitle className="text-sm font-semibold">Tables</CardTitle><Badge variant="secondary" className="text-[10px]">0</Badge></div><p className="mt-1 text-xs text-muted-foreground">Tables from the connected database</p></CardHeader>
          <CardContent className="px-5 pb-5"><div className="rounded-md border border-dashed border-border px-4 py-8 text-center"><Table2 className="mx-auto text-muted-foreground" /><p className="mt-3 text-xs font-medium">No database connected</p><p className="mt-1 text-[11px] text-muted-foreground">Connect a SQLite database to view tables.</p></div></CardContent>
        </Card>

        <Card className="border-border bg-card shadow-none">
          <CardHeader className="flex-col items-stretch gap-4 px-5 pb-4 pt-5 sm:flex-row sm:items-center sm:justify-between sm:gap-3"><div><CardTitle className="text-sm font-semibold">Table explorer</CardTitle><p className="mt-1 text-xs text-muted-foreground">Select a table to inspect its columns and records.</p></div><div className="relative sm:w-52"><Search className="absolute left-2.5 top-2.5 text-muted-foreground" /><input aria-label="Search tables" disabled placeholder="Search tables" className="h-8 w-full rounded-md border border-border bg-background/40 pl-8 pr-3 text-xs text-foreground outline-none placeholder:text-muted-foreground/70 disabled:cursor-not-allowed disabled:opacity-60" /></div></CardHeader>
          <CardContent className="px-5 pb-5"><div className="flex min-h-[260px] flex-col items-center justify-center rounded-md border border-dashed border-border px-6 text-center"><div className="rounded-full border border-border bg-background/50 p-3 text-muted-foreground"><Database /></div><p className="mt-4 text-sm font-medium">No database connected</p><p className="mt-2 max-w-sm text-xs leading-5 text-muted-foreground">Connect a SQLite database to see its schema, row counts, and a preview of records.</p><Button variant="outline" className="mt-5 h-8 border-border text-xs" onClick={() => inputRef.current?.click()}><FileUp data-icon="inline-start" />Connect database</Button></div></CardContent>
        </Card>
      </div>

      <Card className="mt-6 border-border bg-card shadow-none"><CardHeader className="px-5 pb-3 pt-5"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Check className="text-muted-foreground" />Connection status</CardTitle></CardHeader><CardContent className="px-5 pb-5"><div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="size-2 rounded-full bg-muted-foreground" />No database connected<ChevronRight className="ml-auto" /></div></CardContent></Card>
    </main>
  )
}
